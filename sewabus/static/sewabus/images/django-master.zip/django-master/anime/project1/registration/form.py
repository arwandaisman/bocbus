# from django.shortcuts import render,redirect
# from django.contrib import messages
# from django.contrib.auth.models import User
# from django.contrib.auth.forms import UserCreationForm

# # Create your views here.
# class User(UserCreationForm):
#     # email = form.EmailField()

#     class Meta:
#         model = User
#         field = ['username', 'password1', 'password2']