from django.contrib import admin
from manga import models

admin.site.register(models.FormatManga)
admin.site.register(models.Manga)