from django.apps import AppConfig


class FrondendConfig(AppConfig):
    name = 'frondend'
