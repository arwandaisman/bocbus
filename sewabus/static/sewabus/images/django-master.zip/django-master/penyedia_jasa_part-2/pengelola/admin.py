from django.contrib import admin
from pengelola import models

# Register your models here.
admin.site.register(models.murid)
admin.site.register(models.pengajar)
admin.site.register(models.KtgAmpu)