from django.apps import AppConfig


class PengelolaConfig(AppConfig):
    name = 'pengelola'
